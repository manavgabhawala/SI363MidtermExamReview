//
//  ImageCell.swift
//  MidtermExamReview
//
//  Created by Manav Gabhawala on 3/6/16.
//  Copyright © 2016 Manav Gabhawala. All rights reserved.
//

import UIKit

class ImageCell: UITableViewCell
{
	@IBOutlet var iconView: UIImageView!
}